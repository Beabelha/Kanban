export class Tag {
    id: number;
    nome: string;
}

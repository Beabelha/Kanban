export class Client {
  _id: string;
  nome: string;
  desc: string;
  prazo: string;
  estado: string;
  tag: string;
}

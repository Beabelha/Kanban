export class Tarefa {
    _id: string;
    nome: string;
    desc: string;
    prazo: string;
    status: string;
    nomeTag: string;
  }
